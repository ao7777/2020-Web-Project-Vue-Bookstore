<template>
    <div class="navBarContainer">
        <ul class="navBar">
            <li class="menu">
                <a class="menuButton" href="">
                    <i class="fas fa-kiwi-bird"></i>
                </a>
            </li>
            <li :id="menu.name" :key="menu.name" class="menu" v-for="menu in menus">
                <NavButton :Func="menu.ref" :Name="menu.name" :visible="!showSearch"/>
            </li>
            <li :class="[showSearch?'showingSearch':'']">
                <a @click="showSearch=!showSearch" class="searchIcon" href="javascript:">
                    <i class="fas fa-search"></i>
                </a>
            </li>
            <li class="menu">
                <a class="menuButton avatarButton" href="/user">
                    <i class="far fa-user-circle menuButton"></i>
                    {{userName}}
                </a>
            </li>
        </ul>
        <SearchBar :init-book-data="bookData"
                   :show="showSearch"
                   @cancelSearch="showSearch=false"
                   @submit="handleSubmit"
        />
    </div>

</template>

<script>
    import NavButton from "@/components/NavButton";
    import searchicon from "@/assets/searchicon.png";
    import SearchBar from "@/components/SearchBar";

    export default {
        name: "UserInfo",
        props: ['initBookData','loginStatus','initUserInfoData','userInitID'],
        data: function () {
            return {
                userInfoData:this.initUserInfoData,
                menus: [
                    {ref: "./book", name: "图书"},
                    {ref: "./cart", name: "购物车"},
                    {ref: "./order", name: "订单"},
                    {ref: "./account", name: "账号"}
                ],
                showSearch: false,
                searchIcon: searchicon,
                filterText: '',
                bookData: this.initBookData,
                isLogin:this.loginStatus,
            }
        },
        components: {NavButton, SearchBar},
        methods: {
            handleSubmit: function (e) {
                this.filterText = e;
                this.$emit("requestSearch", this.filterText);
            }
        },
        computed:{
            userName:function () {
                if(this.loginStatus){
                    return this.userInfoData[this.userInitID].name;
                }
                else return "登录";
            }
        }
    }
</script>

<style scoped>
    .navBar {
        z-index: 5;
        margin: 0 auto;
        max-width: 700px;
        width: auto;
        list-style: none;
        cursor: default;
        height: 44px;
        display: -ms-flexbox;
        display: flex;
        -ms-flex-pack: justify;
        justify-content: space-between;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    .fa-search {
        display: block;
        background-repeat: no-repeat;
        font-size: 15px;
        font-weight: 600;
        left: -26px;
        position: absolute;
        color: #cccccc;
        transition: color 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
    }

    .fa-search:hover {
        color: #FFFFFF;
    }

    .navBarContainer {
        background-color: rgba(60, 60, 60, 0.8);
        max-height: 44px;
        backdrop-filter: saturate(180%) blur(20px);
        top: 0;
        width: 100%;
        position: fixed;
        z-index: 2;
    }

    .searchIcon {
        position: relative;
        top: 15px;
        transform: translateX(0);
        height: 24px;
        font-family: FontAwesome, sans-serif;
    }

    .avatarButton {
        position: relative;
        top: 9px;
    }

    .showingSearch {
        visibility: hidden;
        transition: 0.5s cubic-bezier(0.645, 0.045, 0.355, 1);
    }

    ul li.menu:nth-child(4) a.menuButton.hidden {
        transition-delay: 0.4s;
    }

    ul li.menu:nth-child(5) a.menuButton.hidden {
        transition-delay: 0.3s;
    }

    ul li.menu:nth-child(6) a.menuButton.hidden {
        transition-delay: 0.2s;
    }

    ul li.menu:nth-child(3) a.menuButton.hidden {
        transition-delay: 0.5s;
    }

    ul li.menu:nth-child(2) a.menuButton.hidden {
        transition-delay: 0.6s;
    }

    .fa-kiwi-bird {
        position: relative;
        top: 10px;
        font-size: 20px;
    }
</style>
