<template>
    <div class="functionBar">
        <button class="floatButton" @click="onClick('books')">
            图书
        </button>
        <button class="floatButton" @click="onClick('cart')">
            购物车
        </button>
        <button class="floatButton" @click="onClick('order')">
            订单
        </button>
        <button class="floatButton" @click="onClick('account')">
            我的账号
        </button>
    </div>
</template>

<script>
    export default {
        name: "FunctionBar",
        props:['displayMode'],
        model:{
          event:"click",
            prop:"displayMode"
        },
        methods:{
            onClick:function (type) {
                this.$emit("displayChange",type);
            }
        }
    }
</script>

<style scoped>

</style>