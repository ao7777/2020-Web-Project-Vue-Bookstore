<template>
    <div>

    </div>
</template>

<script>
    export default {
        name: "AccountInfo"
    }
</script>

<style scoped>

</style>