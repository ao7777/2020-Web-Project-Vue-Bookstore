<template>
  <div id="app">
    <MainInterface />
  </div>
</template>

<script>

import MainInterface from "@/components/MainInterface";

export default {
  name: 'App',
  components: {
    MainInterface
  }
}
</script>


